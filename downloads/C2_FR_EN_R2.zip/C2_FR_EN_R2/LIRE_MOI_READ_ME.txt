C2 — FR/EN — R2
EXTRAIRE le ZIP, puis ouvrir 00_OUVRIR_C2_FR_EN.html dans Chrome ou Edge récent.
PA sur EXTRADOS, cible première gorge INTRADOS.199positions, sixEDM06–11,16915lois. Une seule lecture pilote mouvement et résultats. Les contrôles et la notice sont inclus.
Rejeu mécanique des résultats source : pas une nouvelle qualification physique. Les sixmaxima sont ceux des tables dexamen figées dorigine. Le champ affiché est un gain cohérent, pas encore la rétrodiffusion complète. Le dossier slot est une étude, pas une validation de fabrication.

EXTRACT the ZIP, then open 00_OUVRIR_C2_FR_EN.html in current Chrome or Edge.
PA onEXTRADOS,firstINTRADOSgroove.199positions,sixEDM06–11,16915laws. One playback synchronizes motion and results.
Mechanical replay of source results,not new physical qualification. Sixmaxima come from original frozen examination tables. Displayed field is coherent gain,not complete backscatter. Slot data supports study,not manufacturing qualification.
